OC.L10N.register(
    "announcementcenter",
    {
    "The subject is too long or empty" : "Темата е премногу долга или ја нема",
    "Announcements" : "Објави",
    "Read more" : "Прочитај повеќе",
    "Comments" : "Коментари",
    ", " : ", ",
    "Announce" : "Објави",
    "Visibility" : "Видливост",
    "Everyone" : "Сите"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
