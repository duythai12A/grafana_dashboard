OC.L10N.register(
    "announcementcenter",
    {
    "Comments" : "Kommentarar",
    ", " : ", ",
    "Everyone" : "Alle"
},
"nplurals=2; plural=(n != 1);");
