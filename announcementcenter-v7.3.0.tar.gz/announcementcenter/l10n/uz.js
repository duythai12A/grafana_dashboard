OC.L10N.register(
    "announcementcenter",
    {
    "Announcements" : "E'lonlar",
    "Read more" : "Ko'proq o'qish",
    "Comments" : "Comments",
    "Visibility" : "Ko'rinish",
    "Everyone" : "Everyone"
},
"nplurals=1; plural=0;");
