OC.L10N.register(
    "announcementcenter",
    {
    "You announced “{announcement}”" : "تاسې دغه اعلان وکړ “{announcement}”",
    "{actor} announced “{announcement}”" : "{actor} دغه اعلان وکړ “{announcement}”",
    "You posted an announcement" : "تاسې يو اعلان پوسټ کړ",
    "The announcement does not exist anymore" : "دغه اعلان نور شتون نلري",
    "An <strong>announcement</strong> is posted by an administrator" : "يو اعلان {announcement} د اډمين لخوا پوسټ شو",
    "Announcements" : "اعلانونه",
    "Allow comments by default" : "تبصرو ته اجازه ورکړئ",
    "Comments" : "تبصرې",
    ", " : ", ",
    "_%n comment_::_%n comments_" : ["%nتبصره","%nتبصرې"],
    "Announce" : "اعلان وکړئ",
    "Create activities" : "کړنې جوړې کړئ",
    "Create notifications" : "خبرتيا جوړه کړئ",
    "Allow comments" : "تبصرو ته اجازه ورکړئ"
},
"nplurals=2; plural=(n != 1);");
