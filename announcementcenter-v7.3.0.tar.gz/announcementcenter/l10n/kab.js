OC.L10N.register(
    "announcementcenter",
    {
    "Announcements" : "Ilɣa",
    "Read more" : "Ɣeṛ ugar",
    "{author}, {time}" : "{author}, {time}",
    "Comments" : "Iwenniten",
    ", " : ", ",
    "Delete announcement" : "Kkes alɣu",
    "Everyone" : "Yal yiwen",
    "{author}, {timestamp}" : "{author}, {timestamp}"
},
"nplurals=2; plural=(n != 1);");
