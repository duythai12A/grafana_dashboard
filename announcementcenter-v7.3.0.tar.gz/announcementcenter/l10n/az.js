OC.L10N.register(
    "announcementcenter",
    {
    "Comments" : "Şərhlər",
    ", " : ",",
    "Announce" : "Elan et",
    "Everyone" : "Hamı"
},
"nplurals=2; plural=(n != 1);");
