const fs = require('fs');
const path = require('path');

const iconsDir = path.join(__dirname, 'icons');
const distDir = path.join(__dirname, '..', 'vue');
if (!fs.existsSync(distDir)) fs.mkdirSync(distDir);

// Đọc config
const configPath = path.join(__dirname, 'icon-config.json');
let preserveColorIcons = [];
if (fs.existsSync(configPath)) {
  try {
    const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    preserveColorIcons = cfg.preserveColorIcons || [];
  } catch (err) {
    console.error('⚠️ Lỗi đọc icon-config.json:', err.message);
  }
}

const files = fs.readdirSync(iconsDir).filter(f => f.endsWith('.svg'));
const exportsList = [];

for (const file of files) {
  const name = file.replace(/\.svg$/, '');
  const componentName =
    'VDrive' + name.replace(/(^|_|-)([a-z])/g, (_, __, c) => c.toUpperCase()) + 'Icon';

  let svg = fs.readFileSync(path.join(iconsDir, file), 'utf8');

  // Lấy viewBox, width, height
  const viewBoxMatch = svg.match(/viewBox="([^"]+)"/);
  const widthMatch = svg.match(/width="([^"]+)"/);
  const heightMatch = svg.match(/height="([^"]+)"/);

  const viewBox = viewBoxMatch ? viewBoxMatch[1] : '0 0 24 24';
  const width = widthMatch ? widthMatch[1] : '24';
  const height = heightMatch ? heightMatch[1] : '24';

  // Nội dung SVG
  const innerSvg = svg
    .replace(/<\?xml.*?\?>/, '')
    .replace(/<!DOCTYPE.*?>/, '')
    .replace(/<svg[^>]*>/, '')
    .replace(/<\/svg>/, '')
    .trim();

  // Kiểm tra có nằm trong danh sách giữ màu gốc không
  const preserveColor = preserveColorIcons.includes(name);

  const svgTag = preserveColor
    ? `<svg`
    : `<svg :fill="fillColor"`;

  const vueTemplate = `
<template>
  <span v-bind="$attrs"
        :aria-hidden="title ? null : 'true'"
        :aria-label="title"
        class="material-design-icon ${name}-icon"
        role="img"
        @click="$emit('click', $event)">
    ${svgTag}
         class="material-design-icon__svg"
         :width="size"
         :height="size"
         viewBox="${viewBox}">
      ${innerSvg}
      <title v-if="title">{{ title }}</title>
    </svg>
  </span>
</template>

<script>
export default {
  name: "${componentName}",
  emits: ['click'],
  props: {
    title: {
      type: String,
    },
    fillColor: {
      type: String,
      default: "currentColor"
    },
    size: {
      type: Number,
      default: ${width}
    }
  }
}
</script>
`;

  fs.writeFileSync(path.join(distDir, `${componentName}.vue`), vueTemplate.trim(), 'utf8');
  exportsList.push(`export { default as ${componentName} } from './${componentName}.vue'`);
}

fs.writeFileSync(path.join(distDir, 'index.js'), exportsList.join('\n'), 'utf8');
console.log(`✅ Build complete: ${files.length} icons processed`);
if (preserveColorIcons.length > 0) {
  console.log(`🎨 Preserved colors for: ${preserveColorIcons.join(', ')}`);
}
