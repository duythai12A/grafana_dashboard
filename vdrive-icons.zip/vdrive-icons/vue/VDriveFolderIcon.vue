<template>
  <span v-bind="$attrs"
        :aria-hidden="title ? null : 'true'"
        :aria-label="title"
        class="material-design-icon folder-icon"
        role="img"
        @click="$emit('click', $event)">
    <svg
         class="material-design-icon__svg"
         :width="size"
         :height="size"
         viewBox="0 0 40 40">
      <path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint0_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint1_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint2_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint3_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint4_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint5_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint6_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint7_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint8_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint9_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint10_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint11_radial_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint12_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint13_linear_735_20889)"/>
<path d="M6.30225 6.77148C5.21494 6.77148 4.3335 7.65293 4.3335 8.74023V14.4355C4.3335 14.4992 4.33652 14.5621 4.34242 14.6243V30.4668C4.34242 31.5541 5.22387 32.4355 6.31117 32.4355H33.6979C34.7852 32.4355 35.6666 31.5541 35.6666 30.4668V13.1348C35.6666 12.0475 34.7852 11.166 33.6979 11.166H21.4748C20.8961 11.166 20.3397 10.943 19.9211 10.5434L16.6223 7.39407C16.2037 6.99446 15.6474 6.77148 15.0686 6.77148H6.30225Z" fill="url(#paint14_linear_735_20889)"/>
<rect x="4.3335" y="14.5762" width="31.3242" height="21.2695" rx="1.575" fill="url(#paint15_linear_735_20889)"/>
<rect x="4.3335" y="14.5762" width="31.3242" height="21.2695" rx="1.575" fill="url(#paint16_linear_735_20889)"/>
<rect x="4.3335" y="14.5762" width="31.3242" height="21.2695" rx="1.575" fill="url(#paint17_linear_735_20889)"/>
<rect x="4.3335" y="14.5762" width="31.3242" height="21.2695" rx="1.575" fill="url(#paint18_linear_735_20889)"/>
<rect x="4.3335" y="14.5762" width="31.3242" height="21.2695" rx="1.575" fill="url(#paint19_linear_735_20889)"/>
<defs>
<linearGradient id="paint0_linear_735_20889" x1="20.0001" y1="7.47461" x2="20.0001" y2="15.3496" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFD152"/>
<stop offset="1" stop-color="#FFB83D"/>
</linearGradient>
<linearGradient id="paint1_linear_735_20889" x1="20.841" y1="14.8608" x2="20.841" y2="13.7672" gradientUnits="userSpaceOnUse">
<stop stop-color="#FEB63B"/>
<stop offset="1" stop-color="#FEB63B" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint2_linear_735_20889" x1="4.3335" y1="12.6439" x2="4.57357" y2="12.6439" gradientUnits="userSpaceOnUse">
<stop stop-color="#EFAC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint3_linear_735_20889" x1="35.6666" y1="12.6439" x2="35.5127" y2="12.6439" gradientUnits="userSpaceOnUse">
<stop stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</linearGradient>
<radialGradient id="paint4_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(35.5947 12.1749) rotate(166.264) scale(0.300972 1.58245)">
<stop offset="0.458333" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint5_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(32.177 10.1056) rotate(90) scale(1.32548 6.96916)">
<stop offset="0.822917" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint6_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(26.9114 9.73394) rotate(90) scale(1.73587 6.56959)">
<stop offset="0.822917" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint7_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(23.0218 9.7512) rotate(91.0051) scale(1.81442 4.07236)">
<stop offset="0.822917" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint8_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(18.8525 8.35081) rotate(46.5823) scale(4.07497 1.03608)">
<stop offset="0.822917" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint9_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.3364 6.71813) rotate(46.9512) scale(3.30723 0.374185)">
<stop offset="0.822917" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint10_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(15.4371 6.42774) rotate(31.817) scale(1.5103 0.411925)">
<stop offset="0.623405" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<radialGradient id="paint11_radial_735_20889" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(35.2633 11.7266) rotate(136.685) scale(0.312531 1.64323)">
<stop offset="0.458333" stop-color="#EFBC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</radialGradient>
<linearGradient id="paint12_linear_735_20889" x1="7.37388" y1="6.77148" x2="7.37388" y2="6.97707" gradientUnits="userSpaceOnUse">
<stop stop-color="#EFAC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint13_linear_735_20889" x1="4.96784" y1="7.09256" x2="5.26541" y2="7.28868" gradientUnits="userSpaceOnUse">
<stop stop-color="#EFAC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint14_linear_735_20889" x1="5.3939" y1="6.97083" x2="5.50211" y2="7.20076" gradientUnits="userSpaceOnUse">
<stop stop-color="#EFAC4B"/>
<stop offset="1" stop-color="#EFAC4B" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint15_linear_735_20889" x1="19.9956" y1="14.5762" x2="19.9956" y2="35.8457" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFE155"/>
<stop offset="1" stop-color="#FFB45F"/>
</linearGradient>
<linearGradient id="paint16_linear_735_20889" x1="4.3335" y1="23.9282" x2="4.60621" y2="23.9282" gradientUnits="userSpaceOnUse">
<stop stop-color="#F0B05D"/>
<stop offset="1" stop-color="#F0B05D" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint17_linear_735_20889" x1="19.9956" y1="14.5762" x2="19.9956" y2="15.1048" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFF253"/>
<stop offset="1" stop-color="#FFF253" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint18_linear_735_20889" x1="36.011" y1="15.1048" x2="35.2747" y2="15.1048" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFF253"/>
<stop offset="1" stop-color="#FFF253" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint19_linear_735_20889" x1="24.3673" y1="36.0864" x2="24.3673" y2="33.9074" gradientUnits="userSpaceOnUse">
<stop stop-color="#F9928A"/>
<stop offset="1" stop-color="#FFAD5F" stop-opacity="0"/>
</linearGradient>
</defs>
      <title v-if="title">{{ title }}</title>
    </svg>
  </span>
</template>

<script>
export default {
  name: "VDriveFolderIcon",
  emits: ['click'],
  props: {
    title: {
      type: String,
    },
    fillColor: {
      type: String,
      default: "currentColor"
    },
    size: {
      type: Number,
      default: 40
    }
  }
}
</script>